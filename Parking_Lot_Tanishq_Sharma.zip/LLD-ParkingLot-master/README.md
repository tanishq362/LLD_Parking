# LLD-ParkingLot
Low level design for Parking Lot
Read the complete.pdf file for detailed info
