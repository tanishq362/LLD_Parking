package enums;

public enum VEHICLE_TYPE {

	BIKE, CAR, TRUCK, BUS;
}
