package enums;

public enum ACCOUNT_STATUS {

	ACTIVE, CLOSED, INACTIVE;
}
