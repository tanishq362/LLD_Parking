package enums;

public enum TICKET_STATUS {

	ACTIVE, PAID;
}
