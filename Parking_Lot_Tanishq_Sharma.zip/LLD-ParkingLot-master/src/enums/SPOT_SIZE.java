package enums;

public enum SPOT_SIZE {

	COMPACT, SMALL, MEDIUM, LARGE;
}
