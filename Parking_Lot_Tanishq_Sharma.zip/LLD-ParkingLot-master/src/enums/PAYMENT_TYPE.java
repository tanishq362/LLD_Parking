package enums;

public enum PAYMENT_TYPE {

	CASH, CARD;
}
